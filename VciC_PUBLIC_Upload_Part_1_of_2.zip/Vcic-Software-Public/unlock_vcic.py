#!/usr/bin/env python3
"""Authenticate and unlock one private VciC source ZIP; never extract or run it."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import uuid

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


ROOT = Path(__file__).resolve().parent
MAX_RELEASE_BYTES = 512 * 1024 * 1024
MAX_PART_BYTES = 20 * 1024 * 1024
MAX_JSON_BYTES = 128 * 1024
MAX_PARTS = 64
HASH_PATTERN = re.compile(r"[0-9a-f]{64}")


class UnlockError(ValueError):
    """An invalid or unsafe unlock request, with a non-secret diagnostic."""


def _read_regular(path: Path, limit: int) -> bytes:
    """Read a bounded regular file, rejecting a symlink at the final component."""
    if path.is_symlink():
        raise UnlockError("Symlink input files are not permitted")
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise UnlockError("Input is not a regular file within the size limit")
        data = stream.read(limit + 1)
        if len(data) > limit:
            raise UnlockError("Input exceeds its size limit")
        return data


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise UnlockError("Duplicate JSON fields are not permitted")
        result[key] = value
    return result


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(_read_regular(path, MAX_JSON_BYTES), object_pairs_hook=_unique_object)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise UnlockError("Invalid JSON input") from exc
    if not isinstance(value, dict):
        raise UnlockError("Expected a JSON object")
    return value


def _integer(value, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise UnlockError("Invalid declared size")
    return value


def _hex_digest(value) -> str:
    if not isinstance(value, str) or not HASH_PATTERN.fullmatch(value):
        raise UnlockError("Invalid SHA-256 digest")
    return value


def _b64(value, expected_length: int) -> bytes:
    try:
        if not isinstance(value, str):
            raise ValueError
        result = base64.b64decode(value, validate=True)
        if len(result) != expected_length:
            raise ValueError
        return result
    except (ValueError, TypeError) as exc:
        raise UnlockError("Invalid key or nonce encoding") from exc


def authenticated_metadata(manifest: dict) -> bytes:
    """The five authenticated envelope fields, encoded in a canonical order."""
    fields = ("format", "cipher", "release_id", "plaintext_bytes", "plaintext_sha256")
    return json.dumps({key: manifest[key] for key in fields}, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _outside_repository(path: Path, description: str) -> Path:
    resolved = path.expanduser().resolve()
    if resolved == ROOT.resolve() or ROOT.resolve() in resolved.parents:
        raise UnlockError(f"{description} must be outside the public repository")
    return resolved


def unlock(key_file: Path, output: Path, manifest_file: Path | None = None) -> dict:
    """Decrypt only after full authentication; create a new owner-readable ZIP."""
    key_file = _outside_repository(Path(key_file), "The private key")
    raw_output = Path(output).expanduser().absolute()
    if raw_output.is_symlink():
        raise UnlockError("Output must not be a symlink")
    output = _outside_repository(raw_output, "The decrypted output")
    if output.exists():
        raise UnlockError("Output already exists; choose a new filename")
    manifest_file = Path(manifest_file) if manifest_file else ROOT / "protected/manifest.json"
    manifest_file = manifest_file.expanduser().absolute()
    manifest = _read_json(manifest_file)
    required = {"format", "cipher", "release_id", "nonce_b64", "plaintext_bytes",
                "plaintext_sha256", "ciphertext_bytes", "parts"}
    if set(manifest) != required:
        raise UnlockError("Unexpected manifest fields")
    if manifest["format"] != "VCIC_ENCRYPTED_RELEASE_1" or manifest["cipher"] != "AES-256-GCM":
        raise UnlockError("Unsupported encrypted release format")
    try:
        release_id = str(uuid.UUID(manifest["release_id"]))
    except (ValueError, TypeError, AttributeError) as exc:
        raise UnlockError("Invalid release identifier") from exc
    if release_id != manifest["release_id"]:
        raise UnlockError("Release identifier must use canonical UUID form")
    size = _integer(manifest["plaintext_bytes"], 1, MAX_RELEASE_BYTES)
    digest = _hex_digest(manifest["plaintext_sha256"])
    if _integer(manifest["ciphertext_bytes"], 17, MAX_RELEASE_BYTES + 16) != size + 16:
        raise UnlockError("Ciphertext length does not match AES-GCM framing")
    nonce = _b64(manifest["nonce_b64"], 12)

    key_record = _read_json(key_file)
    if set(key_record) - {"format", "release_id", "key_b64", "public_unlock_sha256"}:
        raise UnlockError("Unexpected private key fields")
    if key_record.get("format") != "VCIC_PRIVATE_KEY_1" or key_record.get("release_id") != release_id:
        raise UnlockError("Key file does not identify this release")
    key = _b64(key_record.get("key_b64"), 32)
    if "public_unlock_sha256" in key_record:
        _hex_digest(key_record["public_unlock_sha256"])

    parts = manifest["parts"]
    if not isinstance(parts, list) or not 1 <= len(parts) <= MAX_PARTS:
        raise UnlockError("Invalid ciphertext part count")
    names = set()
    validated = []
    for part in parts:
        if not isinstance(part, dict) or set(part) != {"file", "bytes", "sha256"}:
            raise UnlockError("Invalid ciphertext part metadata")
        name = part["file"]
        if (not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", name)
                or name in names):
            raise UnlockError("Unsafe or duplicate ciphertext part name")
        names.add(name)
        validated.append((name, _integer(part["bytes"], 1, MAX_PART_BYTES), _hex_digest(part["sha256"])))
    if sum(length for _, length, _ in validated) != manifest["ciphertext_bytes"]:
        raise UnlockError("Ciphertext part lengths do not match the release")
    chunks = []
    for name, length, expected_hash in validated:
        data = _read_regular(manifest_file.parent / name, length)
        if len(data) != length or hashlib.sha256(data).hexdigest() != expected_hash:
            raise UnlockError("Ciphertext part integrity check failed")
        chunks.append(data)
    try:
        plaintext = AESGCM(key).decrypt(nonce, b"".join(chunks), authenticated_metadata(manifest))
    except InvalidTag as exc:
        raise UnlockError("Authentication failed: incorrect key or altered payload") from exc
    if len(plaintext) != size or hashlib.sha256(plaintext).hexdigest() != digest:
        raise UnlockError("Decrypted release identity check failed")

    # No output file or directory is created until all cryptographic checks pass.
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(output, flags, 0o600)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(plaintext)
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        output.unlink(missing_ok=True)
        raise
    return {"status": "PASS", "release_id": release_id, "output": str(output),
            "bytes": size, "sha256": digest, "executed": False}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--key-file", type=Path, required=True, help="Private JSON key file outside this repository")
    parser.add_argument("--output", type=Path, required=True, help="New private ZIP path outside this repository")
    parser.add_argument("--manifest", type=Path, default=None, help="Override protected/manifest.json")
    args = parser.parse_args(argv)
    try:
        result = unlock(args.key_file, args.output, args.manifest)
    except (UnlockError, OSError) as exc:
        # Do not echo data, key material, JSON contents or a traceback.
        message = str(exc) if isinstance(exc, UnlockError) else "File operation failed; check paths and permissions"
        print(f"UNLOCK FAILED: {message}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
