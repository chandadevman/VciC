"""Synthetic encryption fixtures; no production key or private source is stored here."""
from __future__ import annotations

import base64
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import uuid
import zipfile

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

SPEC = importlib.util.spec_from_file_location("unlock_vcic", Path(__file__).resolve().parents[1] / "unlock_vcic.py")
unlocker = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(unlocker)


class UnlockTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.repo = self.base / "public"
        self.protected = self.repo / "protected"
        self.protected.mkdir(parents=True)
        self.root_patch = patch.object(unlocker, "ROOT", self.repo)
        self.root_patch.start()
        self.addCleanup(self.root_patch.stop)
        self.key = AESGCM.generate_key(bit_length=256)
        self.nonce = os.urandom(12)
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w") as archive:
            archive.writestr("example/source.txt", "Synthetic test source only.\n")
        self.plaintext = stream.getvalue()
        self.key_file = self.base / "private.key"
        self.output = self.base / "private-output" / "unlocked.zip"
        self.manifest_file = self.protected / "manifest.json"
        self.manifest = {
            "format": "VCIC_ENCRYPTED_RELEASE_1", "cipher": "AES-256-GCM",
            "release_id": str(uuid.uuid4()), "nonce_b64": base64.b64encode(self.nonce).decode(),
            "plaintext_bytes": len(self.plaintext), "plaintext_sha256": hashlib.sha256(self.plaintext).hexdigest(),
            "ciphertext_bytes": len(self.plaintext) + 16, "parts": [],
        }
        self.key_record = {"format": "VCIC_PRIVATE_KEY_1", "release_id": self.manifest["release_id"],
                           "key_b64": base64.b64encode(self.key).decode()}
        self.key_file.write_text(json.dumps(self.key_record))
        self.encrypt_fixture()

    def write_manifest(self):
        self.manifest_file.write_text(json.dumps(self.manifest))

    def encrypt_fixture(self):
        ciphertext = AESGCM(self.key).encrypt(self.nonce, self.plaintext,
                                             unlocker.authenticated_metadata(self.manifest))
        self.manifest["parts"] = []
        for index, start in enumerate(range(0, len(ciphertext), 64), 1):
            data = ciphertext[start:start + 64]
            name = f"payload.{index:03}.bin"
            (self.protected / name).write_bytes(data)
            self.manifest["parts"].append({"file": name, "bytes": len(data),
                                           "sha256": hashlib.sha256(data).hexdigest()})
        self.write_manifest()

    def expect_failure_without_plaintext(self):
        with self.assertRaises((unlocker.UnlockError, OSError)):
            unlocker.unlock(self.key_file, self.output)
        self.assertFalse(self.output.exists())
        self.assertFalse(self.output.parent.exists())

    def test_correct_key_reproduces_zip_and_private_permissions(self):
        result = unlocker.unlock(self.key_file, self.output)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(self.output.read_bytes(), self.plaintext)
        self.assertFalse(result["executed"])
        if os.name == "posix":
            self.assertEqual(self.output.stat().st_mode & 0o777, 0o600)

    def test_wrong_key_creates_no_plaintext(self):
        self.key_record["key_b64"] = base64.b64encode(AESGCM.generate_key(bit_length=256)).decode()
        self.key_file.write_text(json.dumps(self.key_record))
        self.expect_failure_without_plaintext()

    def test_tamper_even_with_recomputed_public_hash_rejected(self):
        part = self.manifest["parts"][0]
        path = self.protected / part["file"]
        data = bytearray(path.read_bytes()); data[0] ^= 1
        path.write_bytes(data)
        part["sha256"] = hashlib.sha256(data).hexdigest()
        self.write_manifest()
        self.expect_failure_without_plaintext()

    def test_changed_authenticated_metadata_rejected(self):
        self.manifest["plaintext_sha256"] = "0" * 64
        self.write_manifest()
        self.expect_failure_without_plaintext()

    def test_authenticated_but_wrong_plaintext_digest_rejected(self):
        self.manifest["plaintext_sha256"] = "0" * 64
        self.encrypt_fixture()
        self.expect_failure_without_plaintext()

    def test_missing_ciphertext_part_rejected(self):
        (self.protected / self.manifest["parts"][0]["file"]).unlink()
        self.expect_failure_without_plaintext()

    def test_reordered_parts_rejected(self):
        self.manifest["parts"].reverse()
        self.write_manifest()
        self.expect_failure_without_plaintext()

    def test_path_traversal_rejected(self):
        self.manifest["parts"][0]["file"] = "../private.key"
        self.write_manifest()
        self.expect_failure_without_plaintext()

    @unittest.skipUnless(os.name == "posix", "POSIX symlink fixture")
    def test_part_symlink_rejected(self):
        path = self.protected / self.manifest["parts"][0]["file"]
        outside = self.base / "outside.bin"
        path.rename(outside)
        path.symlink_to(outside)
        self.expect_failure_without_plaintext()

    def test_missing_key_rejected(self):
        self.key_file.unlink()
        self.expect_failure_without_plaintext()

    def test_malformed_key_base64_rejected(self):
        self.key_record["key_b64"] = "not-a-key"
        self.key_file.write_text(json.dumps(self.key_record))
        self.expect_failure_without_plaintext()

    def test_key_for_other_release_rejected(self):
        self.key_record["release_id"] = str(uuid.uuid4())
        self.key_file.write_text(json.dumps(self.key_record))
        self.expect_failure_without_plaintext()

    def test_duplicate_json_field_rejected(self):
        text = self.manifest_file.read_text()
        self.manifest_file.write_text('{"cipher":"AES-256-GCM",' + text[1:])
        self.expect_failure_without_plaintext()

    def test_deeply_nested_json_rejected_without_traceback(self):
        self.manifest_file.write_text('[' * 2000 + '0' + ']' * 2000)
        self.expect_failure_without_plaintext()

    @unittest.skipUnless(os.name == "posix", "POSIX FIFO fixture")
    def test_fifo_part_rejected_without_waiting_for_writer(self):
        path = self.protected / self.manifest["parts"][0]["file"]
        path.unlink()
        os.mkfifo(path)
        self.expect_failure_without_plaintext()

    def test_declared_release_size_limit_rejected(self):
        self.manifest["plaintext_bytes"] = unlocker.MAX_RELEASE_BYTES + 1
        self.write_manifest()
        self.expect_failure_without_plaintext()

    def test_existing_output_preserved(self):
        self.output.parent.mkdir()
        self.output.write_bytes(b"Keep existing file")
        with self.assertRaises(unlocker.UnlockError):
            unlocker.unlock(self.key_file, self.output)
        self.assertEqual(self.output.read_bytes(), b"Keep existing file")

    def test_plaintext_output_in_public_repository_rejected(self):
        target = self.repo / "private.zip"
        with self.assertRaises(unlocker.UnlockError):
            unlocker.unlock(self.key_file, target)
        self.assertFalse(target.exists())

    def test_private_key_in_public_repository_rejected(self):
        misplaced = self.repo / "secret.key"
        misplaced.write_bytes(self.key_file.read_bytes())
        with self.assertRaises(unlocker.UnlockError):
            unlocker.unlock(misplaced, self.output)
        self.assertFalse(self.output.exists())

    @unittest.skipUnless(os.name == "posix", "POSIX symlink fixture")
    def test_output_symlink_into_repository_rejected(self):
        link = self.base / "misleading-output"
        link.symlink_to(self.repo, target_is_directory=True)
        with self.assertRaises(unlocker.UnlockError):
            unlocker.unlock(self.key_file, link / "private.zip")
        self.assertFalse((self.repo / "private.zip").exists())

    def test_cli_error_does_not_print_key(self):
        self.manifest["nonce_b64"] = base64.b64encode(os.urandom(12)).decode()
        self.write_manifest()
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = unlocker.main(["--key-file", str(self.key_file), "--output", str(self.output)])
        self.assertEqual(code, 1)
        self.assertEqual(stdout.getvalue(), "")
        self.assertNotIn(self.key_record["key_b64"], stderr.getvalue())
        self.assertIn("Authentication failed", stderr.getvalue())
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
