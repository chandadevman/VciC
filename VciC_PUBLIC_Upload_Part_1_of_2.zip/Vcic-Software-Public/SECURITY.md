# Protected VciC release format

`protected/manifest.json` describes one AES-256-GCM ciphertext, including its 16-byte authentication tag, split into ordered transport parts. Each part's SHA-256 and size provide an early corruption check. They are not publisher signatures; the GCM tag provides keyed authentication.

The nonce is 12 random bytes. The release uses a new 32-byte random key. The production key is only in the separately delivered private owner kit.

The authenticated associated data is UTF-8 JSON with sorted keys and separators `(',', ':')`, containing exactly `format`, `cipher`, `release_id`, `plaintext_bytes` and `plaintext_sha256` from the manifest. These fields are visible but authenticated. The ordered ciphertext is authenticated as a whole. The unlocker also checks the authenticated plaintext byte count and SHA-256 before writing.

The manifest, unlock tool and public ZIP have trusted SHA-256 values in the private owner kit. Check those values through that separate trusted channel before using a public copy. A malicious replacement unlocker could steal a key; public hashes stored beside a malicious replacement do not prevent that attack.

The tool reads bounded input sizes, rejects unsafe part paths, requires a 32-byte key, and writes plaintext only after successful authentication. It refuses to overwrite output or to write plaintext inside its own public checkout. POSIX output permissions are restricted to the owner. Use a trusted local directory and machine; these controls do not protect against a compromised host or an authorized user copying plaintext.

What this does not establish: external security certification, identity-based authorization, per-user revocation, protection for previously published plaintext, protected execution environments, or encryption of newly created runtime data. The original VciC production and semantic qualification boundaries remain unchanged.

On key exposure, treat every copy of this release as decryptable by whoever obtained the key. Stop distributing that key and use a new key and ciphertext for future releases. Previously exposed plaintext cannot be made secret again by deleting a repository file.
