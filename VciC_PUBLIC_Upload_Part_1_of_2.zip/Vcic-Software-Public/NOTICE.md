# Distribution notice

This wrapper and encrypted payload are prepared for publication at the owner's request. The encrypted material remains private VciC/ReapTyc engineering source under the notices contained inside it. Public availability of ciphertext does not grant a license to the protected source or waive those notices.

The unlock tool uses the separately installed `cryptography` package. No dependency source or model weights are bundled. No GitHub publishing action was performed while creating this archive.
