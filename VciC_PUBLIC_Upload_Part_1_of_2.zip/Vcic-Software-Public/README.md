# VciC Software — protected source distribution

VciC is a visual-native coding platform in development, designed to turn user intent into verifiable software through an SI-assisted workspace. The intended system uses vector-color cells, layered data, linked objects and reusable canonical code paths.

This public repository distributes the **encrypted private VciC 0.2.0 source package**. The current development engine supports a bounded set of typed operations and native builds. General application generation, live-model planning quality and production readiness remain NOT PROVEN.

## Public and protected contents

| Public | Encrypted |
|---|---|
| This overview and unlock instructions | Complete 620-file private source repository |
| Auditable unlock tool and its tests | Compiler, runtime, SI intent mapper and workspace implementation |
| Ciphertext chunks and encryption metadata | Registries, schemas, internal documentation and raw evidence |
| Scoped validation summary | Historical archives, original manifests and rollback material |

The protected payload uses **AES-256-GCM authenticated encryption**, a random 256-bit key and a fresh 96-bit nonce. A single authenticated ciphertext is split into transport files. Splitting does not create independently decryptable parts. The key is delivered separately and is not in this repository.

## Upload this public bundle

Extract **VciC_PUBLIC_Encrypted_Repository_0.2.0.zip** and upload the contents of its `Vcic-Software-Public` folder to the public repository. Preserve the `protected/` and `tests/` directories and include `.gitignore` and `.gitattributes` when using Git.

The encrypted payload is split into files of at most 10 MiB. These fit GitHub's documented 25 MiB browser upload limit per file. Upload the extracted files, not the outer ZIP as a substitute for the repository tree.

**Never upload the separate OWNER KEY ZIP, its key file, the decrypted source, or the earlier unencrypted full-repository ZIP.** `.gitignore` reduces accidental staging; it is not access control and does not protect manual uploads or previously committed files.

## Unlock with an authorized key

Requirements: Python 3.10+ and the `cryptography` dependency. The unlocker was tested on Linux x86_64 with Python 3.12.14 and cryptography 50.0.0. Native VciC builds also require a POSIX development environment, a C11 compiler, GNU Make and Bash.

Before giving a downloaded unlock tool access to your key, compare its SHA-256 with the trusted value in your private owner kit. Verify `protected/manifest.json` against the same kit. Use the owner kit's instructions for this check.

From this public folder:

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 unlock_vcic.py \
  --key-file /private/location/vcic-owner-key.json \
  --output /private/location/VciC-Private-0.2.0.zip
```

Replace `/private/location` with a directory outside this public checkout. Do not paste key contents into commands, issues or logs. The tool authenticates the entire payload before writing a new private ZIP. It refuses an existing output and refuses key/output paths inside the public checkout. It does not run or extract downloaded code automatically.

Extract the resulting private ZIP outside this checkout. In its `Vcic-Software` folder:

```bash
python3 tools/verify_encoder_bundle.py
make -j2 all
bash start_encoder.sh --workspace ./encoder-workspace --port 8765
```

Open the exact local URL printed by the launcher. Read the protected `START_HERE.md` for supported requests and current platform limits.

## Security boundary

Encryption protects the bundled private files while they are encrypted. It is not DRM: someone holding the key can retain, alter or share the decrypted source, and a running program uses plaintext in memory. Removing a public download or issuing a new key cannot revoke previously downloaded keys or plaintext. This package does not encrypt future runtime workspace files automatically.

Keep the key in trusted private storage with a backup. There is no recovery backdoor. For a future release, create a new random key and nonce and encrypt again; never reuse a key/nonce pair. See [SECURITY.md](SECURITY.md) for the envelope and integrity boundaries.

## Verification

```bash
python3 -m unittest discover -s tests -v
```

The public tests use disposable synthetic keys and payloads; they contain no production key. `VERIFICATION.json` records scoped release checks. The encrypted package retains the previous native-build, 71-test engine and 7-test workflow evidence. Those tests do not establish production readiness or live-model quality.

References: [cryptography AES-GCM documentation](https://cryptography.io/en/50.0.0/hazmat/primitives/aead/) and [GitHub file uploads](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository).
